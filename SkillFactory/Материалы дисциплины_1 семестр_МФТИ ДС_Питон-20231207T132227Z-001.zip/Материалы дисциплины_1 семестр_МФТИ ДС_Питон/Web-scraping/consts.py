URL = 'https://historik.val.se/val/val2018/slutresultat/R'
